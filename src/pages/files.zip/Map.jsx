import { useState, useEffect } from 'react'
import { MapContainer, TileLayer, Marker, Popup, useMap } from 'react-leaflet'
import { Search, Navigation } from 'lucide-react'
import 'leaflet/dist/leaflet.css'
import { supabase } from '../lib/supabase'
import L from 'leaflet'

// Fix pour les icônes Leaflet
delete L.Icon.Default.prototype._getIconUrl
L.Icon.Default.mergeOptions({
  iconRetinaUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon-2x.png',
  iconUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon.png',
  shadowUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-shadow.png',
})

function LocationMarker({ position, setPosition }) {
  const map = useMap()

  useEffect(() => {
    if (position) {
      map.flyTo(position, 13)
    }
  }, [position, map])

  return position ? (
    <Marker position={position}>
      <Popup>Vous êtes ici</Popup>
    </Marker>
  ) : null
}

export default function MapView() {
  const [position, setPosition] = useState(null)
  const [distributors, setDistributors] = useState([])
  const [searchQuery, setSearchQuery] = useState('')
  const [selectedDistributor, setSelectedDistributor] = useState(null)

  useEffect(() => {
    // Récupérer la position de l'utilisateur
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (pos) => {
          setPosition([pos.coords.latitude, pos.coords.longitude])
        },
        (error) => {
          console.error('Error getting location:', error)
          // Position par défaut (Paris)
          setPosition([48.8566, 2.3522])
        },
        {
          enableHighAccuracy: true,
          timeout: 10000,
          maximumAge: 0
        }
      )
    } else {
      // Position par défaut (Paris)
      setPosition([48.8566, 2.3522])
    }

    // Charger les distributeurs
    loadDistributors()
  }, [])

  const loadDistributors = async () => {
    try {
      const { data, error } = await supabase
        .from('distributors')
        .select('*')
        .limit(50)

      if (error) throw error
      setDistributors(data || [])
    } catch (error) {
      console.error('Error loading distributors:', error)
    }
  }

  const handleLocateMe = () => {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (pos) => {
          setPosition([pos.coords.latitude, pos.coords.longitude])
        },
        (error) => {
          console.error('Error getting location:', error)
        },
        {
          enableHighAccuracy: true,
          timeout: 10000,
          maximumAge: 0
        }
      )
    }
  }

  if (!position) {
    return (
      <div className="h-screen flex items-center justify-center bg-secondary">
        <div className="text-center">
          <div className="w-16 h-16 border-4 border-primary border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-accent-gray">Chargement de la carte...</p>
        </div>
      </div>
    )
  }

  return (
    <div className="relative h-screen pb-20">
      {/* Barre de recherche */}
      <div className="absolute top-4 left-4 right-4 z-[1000]">
        <div className="bg-white rounded-lg shadow-lg p-3 flex items-center gap-2">
          <Search size={20} className="text-accent-gray" />
          <input
            type="text"
            placeholder="Rechercher une machine ou une ville..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="flex-1 outline-none"
          />
        </div>
      </div>

      {/* Bouton de localisation */}
      <button
        onClick={handleLocateMe}
        className="absolute bottom-24 right-4 z-[1000] bg-white rounded-full p-3 shadow-lg"
      >
        <Navigation size={24} className="text-primary" />
      </button>

      {/* Carte */}
      <MapContainer
        center={position}
        zoom={13}
        className="h-full w-full"
      >
        <TileLayer
          attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>'
          url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
        />
        <LocationMarker position={position} setPosition={setPosition} />
        
        {distributors.map((distributor) => (
          distributor.latitude && distributor.longitude && (
            <Marker
              key={distributor.id}
              position={[distributor.latitude, distributor.longitude]}
            >
              <Popup>
                <div className="text-center">
                  <h3 className="font-bold">{distributor.name}</h3>
                  <p className="text-sm text-gray-600">{distributor.address}</p>
                </div>
              </Popup>
            </Marker>
          )
        ))}
      </MapContainer>

      {/* Bottom sheet avec liste des distributeurs proches */}
      {selectedDistributor && (
        <div className="absolute bottom-20 left-0 right-0 bg-white rounded-t-2xl shadow-2xl z-[1000] p-4 max-h-64 overflow-y-auto">
          <div className="w-12 h-1 bg-gray-300 rounded-full mx-auto mb-4"></div>
          <h3 className="font-bold text-lg mb-2">{selectedDistributor.name}</h3>
          <p className="text-sm text-gray-600">{selectedDistributor.address}</p>
        </div>
      )}
    </div>
  )
}

import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { ChevronDown } from 'lucide-react'
import Logo from '../components/Logo'
import Button from '../components/Button'

// Import des icônes de catégories
import iconPain from '../assets/icons/pain.png'
import iconPizza from '../assets/icons/pizza.png'
import iconBurger from '../assets/icons/burger.png'
import iconAlimentaire from '../assets/icons/alimentaire.png'
import iconFleurs from '../assets/icons/fleurs.png'
import iconParapharmacie from '../assets/icons/parapharmacie.png'
import iconAutres from '../assets/icons/autres.png'

// Import des icônes de navigation
import iconCarte from '../assets/icons/carte.png'
import iconFavoris from '../assets/icons/favoris.png'
import iconParametres from '../assets/icons/parametres.png'

export default function Home() {
  const navigate = useNavigate()
  const [locationMode, setLocationMode] = useState('nearby')
  const [citySearch, setCitySearch] = useState('')
  const [userLocation, setUserLocation] = useState(null)
  const [locationError, setLocationError] = useState(null)

  // Fonction pour obtenir la géolocalisation
  const handleNearbySearch = () => {
    setLocationMode('nearby')
    
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          const { latitude, longitude } = position.coords
          setUserLocation({ latitude, longitude })
          setLocationError(null)
          console.log('Position trouvée:', latitude, longitude)
          
          // Naviguer vers la carte avec les coordonnées
          navigate(`/map?lat=${latitude}&lng=${longitude}`)
        },
        (error) => {
          console.error("Erreur de géolocalisation:", error)
          setLocationError("Impossible d'accéder à votre position. Veuillez autoriser la géolocalisation.")
        },
        {
          enableHighAccuracy: true,
          timeout: 10000,
          maximumAge: 0
        }
      )
    } else {
      setLocationError("Votre navigateur ne supporte pas la géolocalisation.")
    }
  }

  const categories = [
    { icon: iconPain, label: 'Pain', value: 'pain' },
    { icon: iconPizza, label: 'Pizza', value: 'pizza' },
    { icon: iconBurger, label: 'Burger', value: 'burger' },
    { icon: iconAlimentaire, label: 'Alimentaire', value: 'alimentaire' },
    { icon: iconFleurs, label: 'Fleurs', value: 'fleurs' },
    { icon: iconParapharmacie, label: 'Parapharmacie', value: 'parapharmacie' },
    { icon: iconAutres, label: 'Autres', value: 'autres' },
  ]

  return (
    <div className="min-h-screen bg-secondary px-4 pt-8 pb-24">
      {/* Logo */}
      <Logo size="lg" />

      {/* Titre */}
      <h1 className="text-3xl font-bold text-center mb-8">DISTRIBUTEURS</h1>

      {/* Recherche par localisation */}
      <div className="space-y-3 mb-8">
        {/* Autour de moi */}
        <button 
          className="w-full bg-white border border-gray-300 rounded-lg px-4 py-3 flex items-center justify-between text-left"
          onClick={handleNearbySearch}
        >
          <span className={locationMode === 'nearby' ? 'text-black' : 'text-accent-lightgray'}>
            Autour de moi
          </span>
          <ChevronDown size={20} className="text-accent-gray" />
        </button>

        {/* Afficher l'erreur si géolocalisation échoue */}
        {locationError && (
          <div className="text-red-500 text-sm px-2">
            {locationError}
          </div>
        )}

        {/* Ville ou code postal */}
        <button 
          className="w-full bg-white border border-gray-300 rounded-lg px-4 py-3 flex items-center justify-between text-left"
          onClick={() => setLocationMode('city')}
        >
          <span className={locationMode === 'city' ? 'text-black' : 'text-accent-lightgray'}>
            Ville ou code postal
          </span>
          <ChevronDown size={20} className="text-accent-gray" />
        </button>
      </div>

      {/* Catégories */}
      <div className="mb-8">
        <h2 className="text-xl font-bold mb-4">Catégories</h2>
        <div className="flex flex-wrap justify-center gap-4">
          {categories.slice(0, 4).map((category) => (
            <button
              key={category.value}
              className="flex flex-col items-center w-20"
              onClick={() => navigate(`/map?category=${category.value}`)}
            >
              <img 
                src={category.icon} 
                alt={category.label}
                className="w-16 h-16 mb-2 object-contain"
              />
              <span className="text-sm text-center text-black font-bold">{category.label}</span>
            </button>
          ))}
          <div className="w-full"></div>
          <div className="flex justify-center gap-4 w-full">
            {categories.slice(4).map((category) => (
              <button
                key={category.value}
                className="flex flex-col items-center w-20"
                onClick={() => navigate(`/map?category=${category.value}`)}
              >
                <img 
                  src={category.icon} 
                  alt={category.label}
                  className="w-16 h-16 mb-2 object-contain"
                />
                <span className="text-sm text-center text-black font-bold">{category.label}</span>
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Bouton ajouter une machine */}
      <Button onClick={() => navigate('/add-distributor')} className="mb-6 text-xl">
        AJOUTER UNE MACHINE
      </Button>

      {/* Barre de navigation en bas */}
      <nav className="fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 px-4 py-3">
        <div className="flex justify-around items-center max-w-md mx-auto">
          <button 
            onClick={() => navigate('/map')}
            className="flex flex-col items-center gap-1"
          >
            <img src={iconCarte} alt="Carte directe" className="w-6 h-6" />
            <span className="text-xs text-black font-medium">Carte directe</span>
          </button>
          
          <button 
            onClick={() => navigate('/favorites')}
            className="flex flex-col items-center gap-1"
          >
            <img src={iconFavoris} alt="Favoris" className="w-6 h-6" />
            <span className="text-xs text-black font-medium">Favoris</span>
          </button>
          
          <button 
            onClick={() => navigate('/settings')}
            className="flex flex-col items-center gap-1"
          >
            <img src={iconParametres} alt="Paramètres" className="w-6 h-6" />
            <span className="text-xs text-black font-medium">Paramètres</span>
          </button>
        </div>
      </nav>
    </div>
  )
}
